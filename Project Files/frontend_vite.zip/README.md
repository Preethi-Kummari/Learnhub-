# Vite App
This is a basic Vite + React project setup.