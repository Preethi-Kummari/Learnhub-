import React from 'react';

export default function AddCourse() {
  return <div>Add Course</div>;
}