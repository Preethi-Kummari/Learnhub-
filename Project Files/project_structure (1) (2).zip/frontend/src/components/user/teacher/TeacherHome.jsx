import React from 'react';

export default function TeacherHome() {
  return <div>Teacher Home</div>;
}