import React from 'react';

export default function EnrolledCourses() {
  return <div>Enrolled Courses</div>;
}