import React from 'react';

export default function CourseContent() {
  return <div>Course Content</div>;
}