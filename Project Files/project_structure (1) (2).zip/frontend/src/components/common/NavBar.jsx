import React from 'react';

export default function NavBar() {
  return <nav>Navigation Bar</nav>;
}