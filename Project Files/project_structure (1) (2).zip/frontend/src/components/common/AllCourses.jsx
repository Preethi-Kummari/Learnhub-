import React from 'react';

export default function AllCourses() {
  return <div>All Courses</div>;
}