import React from 'react';

export default function UserHome() {
  return <div>User Home</div>;
}