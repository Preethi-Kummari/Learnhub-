import React from 'react';

function App() {
  return <div className="App">Welcome to the App</div>;
}

export default App;