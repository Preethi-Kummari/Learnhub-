const mongoose = require('mongoose');

const enrolledSchema = new mongoose.Schema({
  userId: String,
  courseId: String
});

module.exports = mongoose.model('EnrolledCourse', enrolledSchema);