const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  courseId: String,
  amount: Number
});

module.exports = mongoose.model('CoursePayment', paymentSchema);