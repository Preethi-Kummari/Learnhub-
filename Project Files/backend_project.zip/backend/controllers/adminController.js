exports.getAdminDashboard = (req, res) => {
  res.send('Admin Dashboard');
};