exports.getUserProfile = (req, res) => {
  res.send('User Profile');
};